<?php
echo "Hola Mundo!";
phpinfo();